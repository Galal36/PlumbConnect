from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from .models import User, Location

class LocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Location
        fields = ['id', 'city']

class UserSerializer(serializers.ModelSerializer):
    location = LocationSerializer(read_only=True)
    location_id = serializers.PrimaryKeyRelatedField(
        queryset=Location.objects.all(),
        source='location',
        write_only=True
    )

    class Meta:
        model = User
        fields = [
            'id', 'name', 'email', 'phone', 'password', 'location', 'location_id',
            'role', 'status'
        ]
        extra_kwargs = {
            'password': {'write_only': True},
            'email': {'required': False, 'allow_null': True, 'allow_blank': True},
            'name': {'required': True},
        }



    def validate_email(self, value):
        """تحقق أن الإيميل غير مكرر إذا تم إدخاله"""
        if value:
            if User.objects.filter(email=value).exists():
                raise serializers.ValidationError(_("البريد الإلكتروني مستخدم بالفعل."))
        return value

    def validate_name(self, value):
        """الاسم مطلوب ولا يمكن أن يكون فارغًا"""
        if not value.strip():
            raise serializers.ValidationError(_("الاسم لا يمكن أن يكون فارغًا."))
        return value
    
    def validate_phone(self, value):
        if not value.isdigit() or len(value) < 8:
            raise serializers.ValidationError(_("رقم الهاتف غير صالح."))
        return value


    def create(self, validated_data):
        password = validated_data.pop('password')
        user = User(**validated_data)
        user.set_password(password)
        user.save()
        return user

class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token['name'] = user.name
        token['role'] = user.role
        return token
